package excepciones;

public class EstudianteException extends RuntimeException {
    public EstudianteException(String e) {
        super(e);
    }
}
